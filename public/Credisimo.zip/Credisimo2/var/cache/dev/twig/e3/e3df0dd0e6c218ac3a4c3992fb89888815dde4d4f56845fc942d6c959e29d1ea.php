<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Credisimo/modalPlusCredit.html.twig */
class __TwigTemplate_923e94f5a6c3703db5921d3e4c41f8d1ecd39c07c6901652687d04f03a808c29 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Credisimo/modalPlusCredit.html.twig"));

        // line 1
        echo "<!-- The Modal -->
<div class=\"modal\" id=\"listModal\">
    <div class=\"modal-dialog modal-xl\">
        <div class=\"modal-content\">
              
                <!-- Modal Header -->
                <div class=\"modal-header\">
                    <h4 class=\"modal-title\">View Products</h4>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                </div>
        
                <!-- Modal body -->
                <div class=\"modal-body\">
                    <div class=\"form-group\">
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label><sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>Name:</label>
                            </div>
                            <div class=\"col-sm-4\">
                                <input class=\"form-control\" type=\"text\" name=\"prod_name\" placeholder=\"Name\" value=\"\">
                            </div>    
                        </div>
                    </div>
                </div>
                <!-- Modal footer -->
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>
                </div>
            
        </div>
    </div>
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Credisimo/modalPlusCredit.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- The Modal -->
<div class=\"modal\" id=\"listModal\">
    <div class=\"modal-dialog modal-xl\">
        <div class=\"modal-content\">
              
                <!-- Modal Header -->
                <div class=\"modal-header\">
                    <h4 class=\"modal-title\">View Products</h4>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                </div>
        
                <!-- Modal body -->
                <div class=\"modal-body\">
                    <div class=\"form-group\">
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label><sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>Name:</label>
                            </div>
                            <div class=\"col-sm-4\">
                                <input class=\"form-control\" type=\"text\" name=\"prod_name\" placeholder=\"Name\" value=\"\">
                            </div>    
                        </div>
                    </div>
                </div>
                <!-- Modal footer -->
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>
                </div>
            
        </div>
    </div>
</div>", "Credisimo/modalPlusCredit.html.twig", "/var/www/testLaminas/laravel/Credisimo/Credisimo/templates/Credisimo/modalPlusCredit.html.twig");
    }
}
